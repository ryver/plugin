# roundrobin
GLPI - Automatic Round Robin Assignment in ticket by selected category